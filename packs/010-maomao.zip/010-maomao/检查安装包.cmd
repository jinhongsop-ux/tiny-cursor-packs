@echo off
"%~dp0TinyCursor.exe" check
