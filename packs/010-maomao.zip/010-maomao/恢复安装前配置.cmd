@echo off
"%~dp0TinyCursor.exe" restore
