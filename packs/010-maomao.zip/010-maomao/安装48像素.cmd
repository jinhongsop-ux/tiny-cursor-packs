@echo off
"%~dp0TinyCursor.exe" install 48
