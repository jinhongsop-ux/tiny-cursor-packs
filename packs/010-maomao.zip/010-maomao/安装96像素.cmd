@echo off
"%~dp0TinyCursor.exe" install 96
